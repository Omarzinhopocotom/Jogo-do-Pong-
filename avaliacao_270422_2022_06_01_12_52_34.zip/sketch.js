function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  circle(300,200,20)
  rect(5,12,12,90)
rect(587,120,12,90)
}